package com.financetracker.expensetracker.services.stats;

import com.financetracker.expensetracker.dto.GraphDTO;
import com.financetracker.expensetracker.dto.StatsDTO;

public interface StatsService {
    GraphDTO getChartData();
    StatsDTO getStats();

}
