import axios from 'axios';
import { Expense, Income, StatsDTO, GraphDTO, ExpenseFormData, IncomeFormData } from '../types';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Expense API calls
export const expenseApi = {
  getAll: () => api.get<Expense[]>('/expense/all'),
  getById: (id: number) => api.get<Expense>(`/expense/${id}`),
  create: (data: ExpenseFormData) => api.post<Expense>('/expense', data),
  update: (id: number, data: ExpenseFormData) => api.put<Expense>(`/expense/${id}`, data),
  delete: (id: number) => api.delete(`/expense/${id}`),
};

// Income API calls
export const incomeApi = {
  getAll: () => api.get<Income[]>('/income/all'),
  getById: (id: number) => api.get<Income>(`/income/${id}`),
  create: (data: IncomeFormData) => api.post<Income>('/income', data),
  update: (id: number, data: IncomeFormData) => api.put<Income>(`/income/${id}`, data),
  delete: (id: number) => api.delete(`/income/${id}`),
};

// Stats API calls
export const statsApi = {
  getSummary: () => api.get<StatsDTO>('/stats/summary'),
  getChartData: () => api.get<GraphDTO>('/stats/chart'),
};

export default api; 