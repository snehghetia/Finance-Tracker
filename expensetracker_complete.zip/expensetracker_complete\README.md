# Expense Tracker - Complete Project

This project contains both the backend (Spring Boot) and frontend (React) for a complete expense tracking application.

## Project Structure

- `backend/` - Spring Boot application with PostgreSQL database
- `frontend/` - React TypeScript application
- `SETUP_FOR_FRIEND.md` - Setup instructions for running on another machine
- `POSTGRESQL_SETUP.md` - PostgreSQL installation and configuration guide
- `UPDATE_PASSWORD.md` - Database password update instructions

## Quick Start

### Backend Setup
1. Navigate to the `backend` directory
2. Install PostgreSQL and create database 'expensetracker'
3. Update database password in `src/main/resources/application.properties`
4. Run: `mvn spring-boot:run`

### Frontend Setup
1. Navigate to the `frontend` directory
2. Run: `npm install`
3. Run: `npm start`
4. Open http://localhost:3000

## Features

- Add and manage income and expenses
- View financial analytics and charts
- Dashboard with summary statistics
- PostgreSQL database for data persistence
- Modern React UI with Tailwind CSS

## Currency

The application displays amounts in Indian Rupees (₹).

## Database

- PostgreSQL 17.5 recommended
- Database name: expensetracker
- Tables: income, expense

## API Endpoints

- GET /api/expenses - List all expenses
- POST /api/expenses - Add new expense
- GET /api/income - List all income
- POST /api/income - Add new income
- GET /api/stats - Get financial statistics

## Ports

- Backend: http://localhost:8080
- Frontend: http://localhost:3000
- Database: localhost:5432
