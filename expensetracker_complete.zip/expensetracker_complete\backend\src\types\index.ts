export interface Expense {
  id?: number;
  title: string;
  description: string;
  category: string;
  date: string;
  amount: number;
}

export interface Income {
  id?: number;
  title: string;
  amount: number;
  date: string;
  category: string;
  description: string;
}

export interface StatsDTO {
  income: number;
  expense: number;
  latestIncome: Income;
  latestExpense: Expense;
  balance: number;
  minIncome: number;
  maxIncome: number;
  minExpense: number;
  maxExpense: number;
}

export interface GraphDTO {
  expenseList: Expense[];
  incomeList: Income[];
}

export interface ExpenseFormData {
  title: string;
  description: string;
  category: string;
  date: string;
  amount: number;
}

export interface IncomeFormData {
  title: string;
  amount: number;
  date: string;
  category: string;
  description: string;
} 