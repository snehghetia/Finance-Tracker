package com.financetracker.expensetracker.services.expense;

import java.util.List;

import com.financetracker.expensetracker.dto.ExpenseDTO;
import com.financetracker.expensetracker.entity.Expense;

public interface ExpenseService {
     Expense postExpense(ExpenseDTO expenseDTO);

     List<Expense> getAllExpenses();

     Expense getExpenseById(Long id);
     Expense updateExpense(Long id, ExpenseDTO expenseDTO);
     void deleteExpense(Long id);

}
