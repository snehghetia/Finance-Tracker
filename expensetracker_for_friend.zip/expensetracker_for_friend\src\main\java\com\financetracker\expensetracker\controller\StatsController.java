package com.financetracker.expensetracker.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.financetracker.expensetracker.dto.GraphDTO;
import com.financetracker.expensetracker.dto.StatsDTO;
import com.financetracker.expensetracker.services.stats.StatsService;

@RestController
@RequestMapping("/api/stats")
@RequiredArgsConstructor
@CrossOrigin("*")
public class StatsController {

    private final StatsService statsService;

    @GetMapping("/chart")
    public ResponseEntity<GraphDTO> getChartDetails() {
        return ResponseEntity.ok(statsService.getChartData());
    }

    @GetMapping("/summary")
    public ResponseEntity<StatsDTO> getStatsSummary() {
        return ResponseEntity.ok(statsService.getStats());
    }
}