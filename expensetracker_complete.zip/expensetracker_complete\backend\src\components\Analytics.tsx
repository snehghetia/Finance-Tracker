import React, { useEffect, useState } from 'react';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { StatsDTO, GraphDTO } from '../types';
import { statsApi } from '../services/api';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const Analytics: React.FC = () => {
  const [stats, setStats] = useState<StatsDTO | null>(null);
  const [chartData, setChartData] = useState<GraphDTO | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalyticsData = async () => {
      try {
        const [statsRes, chartRes] = await Promise.all([
          statsApi.getSummary(),
          statsApi.getChartData(),
        ]);

        setStats(statsRes.data);
        setChartData(chartRes.data);
      } catch (error) {
        console.error('Error fetching analytics data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalyticsData();
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  // Prepare chart data
  const expenseChartData = {
    labels: chartData?.expenseList.map(expense => expense.title) || [],
    datasets: [
      {
        label: 'Expenses',
        data: chartData?.expenseList.map(expense => expense.amount) || [],
        backgroundColor: 'rgba(239, 68, 68, 0.8)',
        borderColor: 'rgba(239, 68, 68, 1)',
        borderWidth: 1,
      },
    ],
  };

  const incomeChartData = {
    labels: chartData?.incomeList.map(income => income.title) || [],
    datasets: [
      {
        label: 'Income',
        data: chartData?.incomeList.map(income => income.amount) || [],
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: 'rgba(34, 197, 94, 1)',
        borderWidth: 1,
      },
    ],
  };

  const categoryData = {
    labels: ['Income', 'Expenses'],
    datasets: [
      {
        data: [stats?.income || 0, stats?.expense || 0],
        backgroundColor: [
          'rgba(34, 197, 94, 0.8)',
          'rgba(239, 68, 68, 0.8)',
        ],
        borderColor: [
          'rgba(34, 197, 94, 1)',
          'rgba(239, 68, 68, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Analytics</h2>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Financial Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Income:</span>
              <span className="font-semibold text-success-600">
                {formatCurrency(stats?.income || 0)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Expenses:</span>
              <span className="font-semibold text-danger-600">
                {formatCurrency(stats?.expense || 0)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Balance:</span>
              <span className={`font-semibold ${
                (stats?.balance || 0) >= 0 ? 'text-success-600' : 'text-danger-600'
              }`}>
                {formatCurrency(stats?.balance || 0)}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Income Range</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Min Income:</span>
              <span className="font-semibold text-success-600">
                {formatCurrency(stats?.minIncome || 0)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Max Income:</span>
              <span className="font-semibold text-success-600">
                {formatCurrency(stats?.maxIncome || 0)}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Expense Range</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Min Expense:</span>
              <span className="font-semibold text-danger-600">
                {formatCurrency(stats?.minExpense || 0)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Max Expense:</span>
              <span className="font-semibold text-danger-600">
                {formatCurrency(stats?.maxExpense || 0)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Income vs Expenses</h3>
          <Doughnut
            data={categoryData}
            options={{
              responsive: true,
              plugins: {
                legend: {
                  position: 'bottom',
                },
                title: {
                  display: true,
                  text: 'Income vs Expenses Distribution',
                },
              },
            }}
          />
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Income Breakdown</h3>
          <Bar
            data={incomeChartData}
            options={{
              responsive: true,
              plugins: {
                legend: {
                  display: false,
                },
                title: {
                  display: true,
                  text: 'Income by Source',
                },
              },
              scales: {
                y: {
                  beginAtZero: true,
                },
              },
            }}
          />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Expense Breakdown</h3>
        <Bar
          data={expenseChartData}
          options={{
            responsive: true,
            plugins: {
              legend: {
                display: false,
              },
              title: {
                display: true,
                text: 'Expenses by Category',
              },
            },
            scales: {
              y: {
                beginAtZero: true,
              },
            },
          }}
        />
      </div>
    </div>
  );
};

export default Analytics; 