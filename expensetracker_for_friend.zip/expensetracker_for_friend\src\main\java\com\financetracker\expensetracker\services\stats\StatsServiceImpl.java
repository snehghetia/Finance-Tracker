package com.financetracker.expensetracker.services.stats;

import java.time.LocalDate;

import org.springframework.stereotype.Service;
import com.financetracker.expensetracker.repository.IncomeRepository;
import com.financetracker.expensetracker.dto.GraphDTO;
import com.financetracker.expensetracker.dto.StatsDTO;
import com.financetracker.expensetracker.repository.ExpenseRepository;
import lombok.RequiredArgsConstructor;

import com.financetracker.expensetracker.entity.Income;
import com.financetracker.expensetracker.entity.Expense;

import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
@Service
@RequiredArgsConstructor
public class StatsServiceImpl implements StatsService {

    private final IncomeRepository incomeRepository;
    private final ExpenseRepository expenseRepository;

    @Override
    public GraphDTO getChartData() {
        LocalDate end = LocalDate.now();
        LocalDate start = end.minusDays(27); // 28-day range

        GraphDTO dto = new GraphDTO();
        dto.setIncomeList(incomeRepository.findByDateBetween(start, end));
        dto.setExpenseList(expenseRepository.findByDateBetween(start, end));

        return dto;
    }

    public StatsDTO getStats(){
        Double totalIncome = incomeRepository.sumAllAmounts();
        Double totalExpense = expenseRepository.sumAllAmounts();

        Optional<Income> optionalIncome = incomeRepository.findFirstByOrderByDateDesc();
        Optional<Expense> optionalExpense = expenseRepository.findFirstByOrderByDateDesc();
        
        
        StatsDTO statsDTO = new StatsDTO();
        statsDTO.setExpense(totalExpense != null ? totalExpense : 0.0);
        statsDTO.setIncome(totalIncome != null ? totalIncome : 0.0);
        optionalIncome.ifPresent(statsDTO::setLatestIncome);
        optionalExpense.ifPresent(statsDTO::setLatestExpense);

        double income = totalIncome != null ? totalIncome : 0.0;
        double expense = totalExpense != null ? totalExpense : 0.0;
        statsDTO.setBalance(income - expense);
        List<Income> incomeList = incomeRepository.findAll();
        List<Expense> expenseList = expenseRepository.findAll();
        OptionalDouble minIncome = incomeList.stream()
                .mapToDouble(Income::getAmount)
                .min();
        OptionalDouble maxIncome = incomeList.stream()
                .mapToDouble(Income::getAmount)
                .max();
        OptionalDouble minExpense = expenseList.stream()
                .mapToDouble(Expense::getAmount)
                .min();
        OptionalDouble maxExpense = expenseList.stream()
                .mapToDouble(Expense::getAmount)
                .max();

        statsDTO.setMinIncome(minIncome.isPresent() ? minIncome.getAsDouble() : null);
        statsDTO.setMaxIncome(maxIncome.isPresent() ? maxIncome.getAsDouble() : null);
        statsDTO.setMinExpense(minExpense.isPresent() ? minExpense.getAsDouble() : null);
        statsDTO.setMaxExpense(maxExpense.isPresent() ? maxExpense.getAsDouble() : null);

        return statsDTO;
    }
}